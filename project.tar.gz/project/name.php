<?php
echo "hello buddy";
die;
?>