 <div class="panel panel-default" >
		<div class="panel-heading">
			<h2 style="text-align: center;">Deal Products</h2>
		</div>
		<div class="panel-body col-lg-12" >
			<?php
			     $sql ="select * from products"; 
			     $result = mysql_query($sql);
          		 while ($row=mysql_fetch_array($result)){
          		 $temp = $row['product_id'].",".$row['product_image_url'].",".$_SESSION['user_id'];
            ?>
			<div class="col-lg-4">
				<img src="<?php echo $row['product_image_url']; ?>" class="img-reponsive">
				<a href="#" onclick="insertProductToCart(<?php echo "'$temp'"; ?>)" data-toggle="modal" class="btn btn-info" style="color: black;">AddToCart</a>
				<!-- <input type="text" name="quote">
				<a href="#" class="btn" onclick="alert('add to cart')">Qoute Price</a> -->
			</div>
			<?php }
			?>
			<div class="col-lg-4">
				<img src="https://images.shopclues.com/images/thumbnails/82765/160/160/12682322621504778987.jpg" class="img-reponsive">
				<a href="#" onclick="insertProductToCart(<?php echo json_encode($_SESSION); ?>)" data-toggle="modal" class="btn btn-info" style="color: black;">AddToCart</a>
				<!-- <input type="text" name="quote">
				<a href="#" class="btn" onclick="alert('add to cart')">Qoute Price</a> -->
			</div>
			<div class="col-lg-4">
				<img src="https://images.shopclues.com/images/thumbnails/82765/160/160/12682322621504778987.jpg" class="img-reponsive">
				<a href="#" class="btn btn-info" style="color: black;">AddToCart</a>
				<!-- <input type="text" name="quote">
				<a href="#" class="btn" onclick="alert('add to cart')">Qoute Price</a> -->
			</div>
		</div>
	</div>