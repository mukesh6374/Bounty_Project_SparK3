<div class="panel panel-primary">
	<div class="panel-heading">
		
	</div>
	<div class="panel-body">
		<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
					  <th width=25%>Product Info</th>
			          <th width=25%>Product Image</th>
			          <th width=25%>Quoted Price</th>
			          <th width=25%>Acceptance/Rejection</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$mid = $_SESSION['user_id'];
					    $sql = "SELECT * FROM `product_quoted_price_info` where merchant_id = $mid and status=1";
					    $exsql = mysql_query($sql);

					    while ($row = mysql_fetch_array($exsql,MYSQLI_ASSOC)) {
					?>
					   <tr>
					   	<td><?php echo $row['product_id']; ?></td>
					   	<td><img src="<?php echo $row['product_img_url'];?>" alt="product image"></td>
					   	<td><?php echo $row['quoted_price']; ?></td>
					   	<td>
					   		<label id ="notice_accepted_<?php echo $row['request_id'];?>" style="display: none"><span style="color:green">Accepted</span></label>&nbsp;
					   		<label id="notice_rejected_<?php echo $row['request_id'];?>" style="display: none"><span style="color:red">Rejected</span></label><br/>
					   		<a type="button" class="btn btn-success" id="accept_btn_<?php echo $row['request_id'];?>" onclick="update_status(<?php echo $row['request_id'];?>,2)">Accept</a>&nbsp;
					   		<a type="button" class="btn btn-danger" id="reject_btn_<?php echo $row['request_id'];?>" onclick="update_status(<?php echo $row['request_id'];?>,4)">Reject</a>
					   	</td>
					   </tr>
					<?php     
					    }
					?>
				</tbody>
			</table>
		</div>
	</div>
	
</div>