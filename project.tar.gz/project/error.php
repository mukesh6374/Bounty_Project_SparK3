<?php
   echo error_log(404);

?>