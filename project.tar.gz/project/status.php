<?php	
if(isset($_SESSION['user']) && $_SESSION['user']!=''){
	$name=$_SESSION['user']; ?>
	<li>
		<a href="#" ><i class="glyphicon glyphicon-user"></i>&nbsp;
			<main><?php echo $name; ?></main>
			<span>Welcome</span>
		</a>
	</li>
	<li>
		<a href="logout.php">
			<i class="glyphicon glyphicon-log-out"></i>&nbsp;
			<main>Log-Out</main>
			<span>Get Free :)</span>
		</a>
	</li>
	<li>
		<a href="#cartModal" data-toggle="modal">
			<i class="glyphicon glyphicon-cart">cart</i>
		</a>
	</li>
<?php 
}
else if (isset($_SESSION['message'])&& $_SESSION['message']!='') { ?>

		<li>
		<a href="#modal" data-toggle="modal">
			<i class="glyphicon glyphicon-user"></i>&nbsp;
			<main>SignUp</main>
			<span>Completed!</span>
		</a>
	</li>
	<li>
		<a href="#Modal" data-toggle="modal">
			<i class="glyphicon glyphicon-log-in"></i>&nbsp;
			<main>Log-In</main>
			<span>exist account ?</span>
		</a>
	</li>

<?php
}
else if (isset($_SESSION['error']) && $_SESSION['error']!='') {
	if($_SESSION['error']==1){ ?>
		<li>
		<a href="#modal" data-toggle="modal">
			<i class="glyphicon glyphicon-user"></i>&nbsp;
			<main>SignUp</main>
			<span>not have account ?</span>
		</a>
	</li>
	<li>
		<a href="#Modal" data-toggle="modal">
			<i class="glyphicon glyphicon-log-in"></i>&nbsp;
			<main>Log-In</main>
			<span style="color: red;">Invalid Details</span>
		</a>
	</li>
<?php
	}
	else if($_SESSION['error']==2)
	{ ?>
		<li>
		<a href="#modal" data-toggle="modal">
			<i class="glyphicon glyphicon-user"></i>&nbsp;
			<main>Sign-Up</main>
			<span style="color: red;">Already Exist!</span>
		</a>
	</li>
	<li>
		<a href="#Modal" data-toggle="modal">
			<i class="glyphicon glyphicon-log-In"></i>&nbsp;
			<main>Log-In</main>
			<span>exist account ?</span>
		</a>
	</li>
<?php }
	else if($_SESSION['error']==3) { ?>
		<li>
		<a href="#modal" data-toggle="modal">
			<i class="glyphicon glyphicon-user"></i>&nbsp;
			<main>Sign-Up</main>
			<span>not have account ?</span>
		</a>
	</li>
	<li>
		<a href="#Modal" data-toggle="modal">
			<i class="glyphicon glyphicon-log-In"></i>&nbsp;
			<main>Log-In</main>
			<span>exist account ?</span>
		</a>
	</li>
<?php	
	}
}
else {
	?>
	<li>
		<a href="#modal" data-toggle="modal">
			<i class="glyphicon glyphicon-user"></i>&nbsp;
			<main>Sign-Up</main>
			<span>not have account ?</span>
		</a>
	</li>
	<li>
		<a href="#Modal" data-toggle="modal">
			<i class="glyphicon glyphicon-log-In"></i>&nbsp;
			<main>Log-In</main>
			<span>exist account ?</span>
		</a>
	</li>
<?php 
}
?>