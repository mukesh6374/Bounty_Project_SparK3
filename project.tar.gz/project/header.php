<nav class="navbar" style="margin-bottom: 0px;">
			<div class="navbar-header">
				<div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span> 
			      </button>
			      <a class="navbar-brand" href="index.php"><img src="images/shoplogo.png" style="height: 35px; width: 250px;"></a>
			    </div>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
		      <ul class="nav navbar-nav">
		      			<li>
		      				<a href="electronics.php">
		      					<i  style="font-size: 20px;" class="glyphicon glyphicon-star"></i>
		      					&nbsp;
		      					<main>Electronics</main>
		      					<span>People Need</span>
		      				</a>
						<li>
							<a href="Event.php" target="__blank">
								<i  style="font-size: 20px;" class="glyphicon glyphicon-star"></i>
								&nbsp;
								<main>Fashion</main>
								<span>People Wear</span>
					    	</a>
						</li>
					    <li>
					    	<a href="gym.php" target="__blank">
					    		<i  style="font-size: 20px;" class="glyphicon glyphicon-headphones"></i>
					    		&nbsp;
					    		<main>Shopping</main>
					    		<span>Fun Time!</span>
					    	</a>
					    </li>
						<li>
							<a href="remind.php" target="__blank">
								<i  style="font-size: 20px;" class="glyphicon glyphicon-film"></i>
								&nbsp;
								<main>Events</main>
								<span>Exercise Time!</span>
					    	</a>
					    </li>
			</ul>
			<ul class="nav navbar-nav navbar-right">

						<?php include'status.php' ?>
			</ul>
    </div>
		
			
		</nav>