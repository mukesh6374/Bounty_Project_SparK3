<div class="container">
	<div class="col-lg-12">
		<div class="col-lg-3">
			<a href="">
				<img src="images/g1.jpg" class="img-responsive">
				new product is available for bidding
				<button class="btn">Start Bidding</button>
				
			</a>
		</div>
		<div class="col-lg-3">
			<a href="">
				<img src="images/g1.jpg" class="img-responsive">
				new product is available for bidding
				<button class="btn">Start Bidding</button>
			</a>
		</div>
		<div class="col-lg-3">
			<a href="">
				<img src="images/g1.jpg" class="img-responsive">
				new product is available for bidding
				<button class="btn">Start Bidding</button>
			</a>
		</div>
	</div>
</div>