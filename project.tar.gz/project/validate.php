
<?php 

include('connect.php'); 
$_SESSION['user']="";
$_SESSION['email']="";
$_SESSION['login']=0;
$_SESSION['register']=0;
$_SESSION['error']=0;

$function_name = $_REQUEST['func'];
if($function_name == "login"){
    $status = login();
    echo $status;
}
else if($function_name == "register"){
    $status = register();
    echo $status;
}
else if ($function_name=="insertProductToCart") {
  $status = insertProductToCart();
  echo $status;
}
else if($function_name=="getCM"){
  $status = getCM();
  echo $status;
}
else if($function_name=="update_status"){
  $status = update_status();
  echo $status;
}

function insertProductToCart(){

  if(isset($_REQUEST['data']) && $_SERVER['REQUEST_METHOD']=='POST'){
    $data= $_REQUEST['data'];
    $data = explode(',', $data);
    $product_id = $data[0];
    $user_id = $data[2];
    $product_image_url = $data[1];
    $quatity =1;
    $status = NULL;
    $status_description='ready for bidding';
    $sql = "INSERT INTO `cart_products` VALUES ($product_id ,$user_id ,'$product_image_url' ,$quatity,'$status','$status_description')";
    $inserted = mysql_query($sql);
    if($inserted){
      return true;
    }
    else{
      return false;
    }
  }
}
function login(){

  if(isset($_REQUEST['user'])&&isset($_REQUEST['pwd'])&& $_SERVER['REQUEST_METHOD']=='POST')
      { 
          $user  = $_REQUEST['user'];
          $paswd = $_REQUEST['pwd'];
          $query="select id,username,email,passwrd,user_type from `project` where (username='$user' or email='$user') and passwrd ='$paswd'";
         
          $result=mysql_query($query);
          while ($row=mysql_fetch_array($result))
           {  
              if(($row['username']==$user || $row['email']==$user) && $row['passwrd']==$paswd)
              { 
                $_SESSION['user']=$row['username'];
                $_SESSION['user_type'] =$row['user_type'];
                $_SESSION['user_id'] =$row['id'];
                return true;
              } 
           }
           $_SESSION['error']=1;
           return false;
      }
} 
function register(){

  if(isset($_REQUEST['user'])&&isset($_REQUEST['pwd'])&& isset($_REQUEST['mbno']) && $_REQUEST['email'] && $_SERVER['REQUEST_METHOD']=='POST')
      {
             $user  = $_REQUEST['user'];
             $paswd = $_REQUEST['pwd'];
             $mbno  = $_REQUEST['mbno'];
             $email = $_REQUEST['email'];
             $dob   = $_REQUEST['dob'];
             $query="select username,passwrd,email from `project` where username ='$user' or email='$email' or mobile_no='$mbno'";
             $result=mysql_query($query);
             while($row=mysql_fetch_array($result))
             {     
                   if($row['username']==$user || $row['email']==$email || $row['mobile_no']==$mbno)
                           {    
                                $_SESSION['error'] = 2;
                                 return false;
                           }
             }

             $sql = "INSERT into project (username,email,passwrd,mobile_no,dob) VALUES ('$user','$email','$passwrd','$mbno','$dob')";
             $inserted = mysql_query($sql);

             if($inserted){
                $_SESSION['message'] = "Completed!";
                return true;
             }
             else{
              $_SESSION['error'] = 3;
              return false;
             }

             
      
      }
      return false;

}
function getCM(){
    $pid = $_REQUEST['product_id'];
    $user_id = $_REQUEST['user_id'];
    $user_pincode = $_REQUEST['user_pincode'];
    $quoted_price = $_REQUEST['quoted_price'];
    $product_image_url = $_REQUEST['product_image_url'];

    $sql =  "SELECT merchant_id,merchant_zone from `products` where product_id = $pid";
    $result = mysql_query($sql);
    $row = mysql_fetch_array($result,MYSQLI_ASSOC);
    $mzone = $row['merchant_zone'];
    $merchant_id = $row['merchant_id'];
    $czone = getZoneByPincode($user_pincode);//print_r($row);print_r($mzone);print_r($czone);die;
    $result = first_order_verification($pid,$quoted_price);//print_r($result);die;
    if($result != 1){
      return $result;
    } else {
      $sql = "SELECT sc FROM `zone_wise_shipping_cost` WHERE merchant_zone ='$mzone' AND customer_zone ='$czone'";
      $result = mysql_query($sql);
      $row = mysql_fetch_array($result,MYSQLI_ASSOC);//print_r($row);
      $sc = $row['sc'];

      $sql = "SELECT dp,cm FROM `rev_cost_info` where pid = $pid and mzone = '$mzone' and czone ='$czone'";
      $result = mysql_query($sql);
      $row = mysql_fetch_array($result,MYSQLI_ASSOC);//print_r($row);
      $dp = $row['dp'];
      //(cm/dp)*qp
      $cm = ($row['cm']/$row['dp'])*$quoted_price;//print_r($cm);
      $per_cm = (($cm - $row['cm'])/$row['cm'])*100;//print_r($per_cm);

      $resp = is_cm_in_range($per_cm,$row['dp']);//print_r("dfsdfd".$resp);die;
      $status_desc="";
      if($resp == 1){
        $status_desc = "your quoted price is accepted!! merchant response will be updated soon";
      } else if($resp == 2){
        $status_desc = "your quoted price is very low";
      } else if($resp == 3){
         $status_desc = "your quoted price is very low";
      }
      $sql = "UPDATE `cart_products` SET status='$resp',status_description ='$status_desc' WHERE product_id='$pid' AND user_id=$user_id";//print_r($sql);
      $updated = mysql_query($sql);//print_r($updated);die;
      if($resp == 1){ 
        // echo "your quoted price is accepted!! merchant response will be updated soon";
        $sql ="INSERT INTO product_quoted_price_info(product_id,product_img_url,user_id,merchant_id,merchant_price,quoted_price,contributional_margin,status) VALUES($pid,'$product_image_url',$user_id,$merchant_id,$dp,$quoted_price,$cm,$resp)";
        $inserted = mysql_query($sql);
        if($inserted){
          return 1;
        }
        else{
          return 5;
        }
        

      } else if($resp == 2){
        // echo "your quoted price is very low";
        return 2;
      } else if($resp == 3){
        return 3;
      }
    }
  

}
function getZoneByPincode($pincode){
    $zone_arr= array ('EASTERN' => 1, 'WESTERN' => 2, 'NORTHERN' => 3, 'SOUTHERN' => 4, 'NORTH EASTERN' => 5, 'ISLANDS' =>6);
    if(empty($pincode) or strlen($pincode)<6)
    {
        return 0; // NO Zone for Invalid Pincode
    }
    $three_digits = substr($pincode,0,3);
    if($three_digits == 682 or $three_digits == 744)
    {
        $zone = 'I';
        return $zone;
    }
    $two_digits = substr($three_digits,0,2);
    if($two_digits == 78 or $two_digits == 79)
    {
        $zone = 'NE';
        return $zone;
    }
    $one_digit = substr($two_digits,0,1);
    switch($one_digit)
    {
        case 1 : $zone = 'N';break;
        case 2 : $zone = 'N';break;
        case 3 : $zone = 'W';break;
        case 4 : $zone = 'W';break;
        case 5 : $zone = 'S';break;
        case 6 : $zone = 'S';break;
        case 7 : $zone = 'E';break;
        case 8 : $zone = 'E';break;
        default: $zone = 0;
    }
    return $zone;
}
function is_cm_in_range($per_cm,$deal_price){
    if($deal_price > 0 && $deal_price <= 100){
      //50%
      $lt = -50;
      $rt = 50;
      if($per_cm < $lt){
        return 2;
      } else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }

    } elseif ($deal_price > 100 && $deal_price <= 500){
       // 40%
      $lt = -40;
      $rt = 40;
      if($per_cm < $lt){
        return 2;
      } else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }
    
    } elseif($deal_price > 500 && $deal_price <= 1000){
         // 35%
      $lt = -35;
      $rt = 35;
      if($per_cm < $lt){
        return 2;
      } else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }
 
    } elseif($deal_price > 1000 && $deal_price <= 5000){
       // 25% reduce  // 25 % high price
      $lt = -25;
      $rt = 25;
      if($per_cm < $lt){
        return 2;
      } else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }

    } elseif($deal_price > 5000 && $deal_price <= 10000){
      // 15 % both side
      $lt = -15;
      $rt = 15;
      if($per_cm < $lt){
        return 2;
      
      } else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }

    } elseif($deal_price > 10000 && $deal_price <= 50000){
       //10% both side
      $lt = -10;
      $rt = 10;
      if($per_cm < $lt){
        return 2;
      }
       else if($per_cm > $rt){
         return 3;
      } else {
        return 1;
      }
    }
}

function first_order_verification($pid,$quoted_price){
     $sql= "SELECT dp FROM rev_cost_info where pid = $pid";
     $result = mysql_query($sql);
     $row = mysql_fetch_array($result,MYSQLI_ASSOC);
    $deal_price = $row['dp'];
    if($deal_price > 0 && $deal_price <= 100){
      //50%
      $lt = $deal_price/2;
      $rt = $deal_price + $lt;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }

    } elseif ($deal_price > 100 && $deal_price <= 500){
       // 40%
      $lt = $deal_price - ($deal_price*40)/100;
      $rt = $deal_price + ($deal_price*40)/100;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }
    
    } elseif($deal_price > 500 && $deal_price <= 1000){
         // 35%
       $lt = $deal_price - ($deal_price*35)/100;
      $rt = $deal_price + ($deal_price*35)/100;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }
 
    } elseif($deal_price > 1000 && $deal_price <= 5000){
       // 25% reduce  // 25 % high price
      $lt = $deal_price - ($deal_price*25)/100;
      $rt = $deal_price + ($deal_price*25)/100;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }

    } elseif($deal_price > 5000 && $deal_price <= 10000){
      // 15 % both side
      $lt = $deal_price - ($deal_price*15)/100;
      $rt = $deal_price + ($deal_price*15)/100;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }

    } elseif($deal_price > 10000 && $deal_price <= 50000){
       //10% both side
       $lt = $deal_price - ($deal_price*10)/100;
      $rt = $deal_price + ($deal_price*10)/100;
      if($quoted_price < $lt){
        return 2;
      } else if($quoted_price > $rt){
        return 3;
      } else {
        return 1;
      }
    }
}

function update_status(){
   $request_id= $_REQUEST['request_id'];
   $status    = $_REQUEST['status'];
   if($status == 2){
    $return_status =1;
   }
   else
   {
     $return_status =2;
   }
   $sql = "UPDATE `product_quoted_price_info` SET status ='$status' WHERE request_id =$request_id";
   $result = mysql_query($sql);

   if($result){
     if($status==2){
       $status= 1;
       $status_description = "accepted";
     } else if($status == 4){
        $status_description = "rejection";
     }
     
      $sql = "UPDATE `cart_products` SET status='$status', status_description='$status_description'";
      $result = mysql_query($sql);
   }
   return $return_status;
}  
      
?>