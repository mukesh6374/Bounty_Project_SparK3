<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  /*
  $(document).ready(function(){
    $("#accept_btn").click(function(){
        $("#accept_btn").hide();
        $("#reject_btn").hide();
        $("#notice_accepted").show();
    });

    $("#reject_btn").click(function(){
        $("#accept_btn").hide();
        $("#reject_btn").hide();
        $("#notice_rejected").show();
    });

  }); */
  
function update_status(request_id,status){
    var accept_btn_id = "#accept_btn_"+request_id;
    var reject_btn_id = "#reject_btn_"+request_id;
    var notice_accepted_id = "#notice_accepted_"+request_id;
    var notice_rejected_id = "#notice_rejected_"+request_id;
    $.ajax({
         type:"POST",
         data:{"request_id":request_id,"status":status,"function_name":"update_status"},
         url:"queries.php",
         success:function(){
            $(accept_btn_id).hide();
            $(reject_btn_id).hide();
            if(status == 1){
              $(notice_accepted_id).show();
            } else{
              $(notice_rejected_id).show();
            }
         }
    });
  }
  </script>
  <style>
    
  </style>
</head>
<body>
<?php 
  include 'connect.php';
  $mid = $_REQUEST['merchant_id'];
  $sql = "SELECT * FROM `product_quoted_price_info` where merchant_id = ".$mid;
  $exsql = mysql_query($sql);
  //$result = mysqli_fetch_array($exsql,MYSQLI_ASSOC); 
  //echo '<pre>'; print_r($result);
?>
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3>Request for your Produsts !</h3>
  </div>
  <div class="panel-body">
   <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th width=25%>Product Info</th>
          <th width=25%>Product Image</th>
          <th width=25%>Quoted Price</th>
          <th width=25%>Acceptance/Rejection</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysql_fetch_array($exsql,MYSQLI_ASSOC)) { ?>
        <tr>
          <td>ProductId:<?php echo $row['product_id']; ?></td>
          <td><img src="<?php echo $row['product_img_url'];?>" alt="product image"></td>
          <td><?php echo $row['quoted_price']; ?></td>
          <td>
            <label id ="notice_accepted_<?php echo $row['request_id'];?>" style="display: none"><span style="color:green">Accepted</span></label>&nbsp;
            
            <label id="notice_rejected_<?php echo $row['request_id'];?>" style="display: none"><span style="color:red">Rejected</span></label><br/>
            <button type="button" class="btn btn-success" id="accept_btn_<?php echo $row['request_id'];?>" onclick="update_status(<?php echo $row['request_id'];?>,1)">Accept</button>&nbsp;
            <button type="button" class="btn btn-danger" id="reject_btn_<?php echo $row['request_id'];?>" onclick="update_status(<?php echo $row['request_id'];?>,2)">Reject</button>
            
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
   </div>
  </div>
  <div class="panel-footer">
    Panel Footer
  </div>
</div>


</body>
</html>