  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
    <div class="item active">
      <div style="background-image: url('images/bg1.jpg');width:100%; height: 400px;">
        <h2 style="margin-top: 0px; padding-top: 100px; color: black; margin-left: 180px; text-transform: uppercase;">Deals on Large <br><span style="color: red; margin-left: 100px;">Appliances<br></span> <span style="margin-left: 150px;">Flat <i>25% Discount</i></span></h2>
      </div>
    </div>
    <div class="item">
      <div style="background-image: url('images/bg2.jpg');width:100%; height: 400px; ">
        <h2 style="margin-top: 0px; padding-top: 100px; color: black; margin-left: 180px;">Deals on Large <br><span style="color: red; margin-left: 100px;">Appliances<br></span> <span style="margin-left: 150px;">Flat <i>25% Discount</i></span></h2>
      </div>
    </div>
    <div class="item">
      <div style="background-image: url('images/bg3.jpg');width:100%; height: 400px; ">
        <h2 style="margin-top: 0px; padding-top: 100px; color: black; margin-left: 180px;">Deals on Large <br><span style="color: red; margin-left: 100px;">Appliances<br></span> <span style="margin-left: 150px;">Flat <i>25% Discount</i></span></h2>
      </div>
    </div>
    <div class="item">
      <div style="background-image: url('images/bg4.jpg');width:100%; height: 400px; ">
        <h2 style="margin-top: 0px; padding-top: 100px; color: black; margin-left: 180px;">Deals on Large <br><span style="color: red; margin-left: 100px;">Appliances<br></span> <span style="margin-left: 150px;">Flat <i>25% Discount</i></span></h2>
      </div>
    </div>
  </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>