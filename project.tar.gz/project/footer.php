<footer class="footer-distributed">

			<div class="footer-right">

				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-linkedin"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>

			</div>

			<div class="footer-left">

				<p class="footer-links">
					<a href="#">Home</a>
					·
					<a href="#">Contact</a>
				</p>

				<p>ClearVision &copy; 2017 mukesh6374 (Mukesh Kumar C2424), Prince(C2425) , Sagarika(C2410)</p>
			</div>

		</footer>