<div class="container">
	<div class="col-lg-12">
		<div class="col-lg-5">
			<img src="images/g1.jpg" class="img-responsive">
		</div>
		<div class="col-lg-4">
			<h3>Patanjali Dant Kanti Advanced 100Gm</h3>
			<h4>Patanjali Product Id : 124468460</h4>
			<button class="btn" value="Bid Now"></button>
		</div>
		<div class="col-lg-3">
			
		</div>
	</div>
</div>