<?php
$con = mysql_connect("localhost","root","root");
mysql_select_db("web", $con);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 session_start();

// some code
  // mysql_select_db("web", $con);
?>