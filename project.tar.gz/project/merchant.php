<!DOCTYPE html>
<html lang="en">

<?php 
error_reporting(0); ?>	
<?php include('connect.php'); ?>
<head>
	<title>Day3</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/footer.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/clockdemo.css">
	<link href='//fonts.googleapis.com/css?family=Offside' rel='stylesheet' type='text/css'>
<?php include('login.php'); ?>
<?php include('register.php'); ?>
<?php include('modal.php'); ?>
<?php include('cart.php'); ?>
</head>

<body>
	<?php
			session_start();
	?>
	<div id="wrapper">
		<?php include'header.php'; ?>
		
	</div>

<script type="text/javascript" src="js/kinetic.js"></script>
<script type="text/javascript" src="js/jquery.final-countdown.js"></script>
<script type="text/javascript">  
    $('document').ready(function() {
        'use strict';
        
        $('.countdown').final_countdown({
            'start': 1362139200,
            'end': 1388461320,
            'now': 1387461319        
        });
    });
</script>

</body>
</html>