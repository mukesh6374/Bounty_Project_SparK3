<div class="container">
<!-- Modal -->
<div id="cartModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" style="width: 700px;">
      <div class="modal-body" style="color: white; background-color: rgba(10,10,10,10);">
        <div class="table-responsive">
          <table class="table">
            <thead>
              Enter Pincode: <input type="number" id ="user_pin" name="user_pin" style="color: black;">
              <tr>
                <tr>
                <th>Product_id</th>
                <th>Image</th>
                <th>Quantity</th>
                <td>Quote Price</td>
                <td>status</td>
              </tr>
              </tr>
            </thead>
            <tbody>
              
              <?php
                    $user_id = $_SESSION['user_id'];
                    $sql ="SELECT * from `cart_products` where user_id = $user_id";
                    $result = mysql_query($sql);
                    while($row = mysql_fetch_array($result)){
              ?>
              <input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id; ?>">
              <tr>
                <td><?php echo "#".$row['product_id'];?></td>
                <td><img id="<?php echo 'image'.$row['product_id']; ?>" src="<?php echo $row['product_image_url']; ?>" class="img-responsive"></td>
                <td><?php echo $row['quatity'];?></td>
                <?php if($row['status']!=1){ ?>
                <td><input type="text" id="<?php echo 'quote'.$row['product_id']; ?>" name="quote_price" style="color: black;"></input></td>
                <td><?php echo $row['status_description'];?></td>
                <td><a href="#" onclick="getCM(<?php echo $row['product_id']; ?>)" class="btn btn-success">BID</a></td>
                <?php }
                else {
                  ?>
                <td><input type="text" disabled placeholder="wait for acceptance" style="color: black;"></input></td>
                <td><?php echo $row['status_description'];?></td>
                <td><a href="#" disabled class="btn btn-success">BID</a></td>
                <?php }

                if($row['status']==1){
                   ?>
                   <td><a href="#" class="btn btn-danger">BUY NOW</a></td>

                  <?php } ?>

              </tr>
              <?php 
            } ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</div><!-- Trigger the modal with a button -->
  
