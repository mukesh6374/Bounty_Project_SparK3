<!DOCTYPE html>
<html lang="en">

<?php 
error_reporting(0); ?>	
<?php include('connect.php'); ?>
<head>
	<title>Day3</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css"> 
	<link rel="stylesheet" type="text/css" href="css/footer.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/clockdemo.css">
	<link href='//fonts.googleapis.com/css?family=Offside' rel='stylesheet' type='text/css'>
<?php include('login.php'); ?>
<?php include('register.php'); ?>
<?php include('cart.php'); ?>
</head>

<body>
	<div id="wrapper">
    <?php
      if(isset($_SESSION['user_type']) && $_SESSION['user_type']==1){
        include 'header.php';
        include 'merchants.php';
      }
      else
      {
        include 'header.php';
        include 'slider.php';
        include 'product.php';
      }
    ?>
	</div>

<script type="text/javascript" src="js/kinetic.js"></script>
<script type="text/javascript" src="js/jquery.final-countdown.js"></script>
<script type="text/javascript">  
    $('document').ready(function() {
        'use strict';
        
        $('.countdown').final_countdown({
            'start': 1362139200,
            'end': 1388461320,
            'now': 1387461319        
        });
    });

    $('#logbtn').click(function(){
    	var funct = $('#login_func').val();
    	var users = $('#login_user').val();
    	var pwdd  = $('#login_pwd').val();
    	console.log(funct);
    	console.log(users);
    	console.log(pwdd);
    	// alert("hello");
    	// $.ajax({
    	// 	type: "POST",
    	// 	url : "validate.php",
    	// 	data: {'func':login_func,'user':user,'pwd':pwd},
    	// 	success:function(msg){
    			
    	// 	},
    	// 	error
    	// });
    	//  // $.ajax({
     //  //           type: "POST",
     //  //           url: "validate.php",
     //  //           data:{'func':login_func,'user':user,'pwd':pwd},
     //  //           success:function (msg){
     //  //           	alert("done");
     //  //           },
     //  //           error:function (data, textStatus, jqXHR) {alert("Error Occured");}
     //  //         });

     $.ajax({
                type: "POST",
                url: "validate.php",
                cache:false,
                data:{'func':funct,'user':users,'pwd':pwdd},
                success:function(msg){
                	console.log(msg);
                	$(location).attr('href','index.php');
                },
                error:function (data, textStatus, jqXHR) {
                	alert("Error Occured");
                }
              });
    });

    function insertProductToCart(data){
          $.ajax({
                type: "POST",
                url: "validate.php",
                cache:false,
                data:{'func':'insertProductToCart','data':data},
                success:function(msg){
                  console.log(msg);
                  if(msg==1){
                    alert("Your cart is Ready!!");
                    $('#cartModal').modal();
                  }
                  else
                    alert("Your cart is not Ready!!");
                  
                },
                error:function (data, textStatus, jqXHR) {
                  alert("Error Occured");}
              });  
    }

    function getCM(product_id){
        var user_id = $('#user_id').val();
        var user_pincode = $('#user_pin').val();
        var quoted_price = $('#quote'+product_id).val();
        var product_image_url = $('#image'+product_id).attr('src');alert(product_image_url);
        console.log(this.id);
        $.ajax({
                type: "POST",
                url: "validate.php",
                cache:false,
                data:{'func':'getCM','product_image_url':product_image_url,'product_id':product_id,'user_id':user_id,'user_pincode':user_pincode,'quoted_price':quoted_price},
                success:function(msg){
                  console.log(msg);
                  if(msg==1){
                    $('#cartModal').close();
                    $('#cartModal').modal();
                  }
                  else
                    alert("Your cart is not Ready!!");
                },
                error:function (data, textStatus, jqXHR) {
                  alert("Error Occured");}
              });
    }


    function update_status(request_id,status){
    var accept_btn_id = "#accept_btn_"+request_id;
    var reject_btn_id = "#reject_btn_"+request_id;
    var notice_accepted_id = "#notice_accepted_"+request_id;
    var notice_rejected_id = "#notice_rejected_"+request_id;
    $.ajax({
         type:"POST",
         data:{'func':'update_status','request_id':request_id,'status':status},
         url:'validate.php',
         success:function(msg){
            $(accept_btn_id).hide();
            $(reject_btn_id).hide();
            if(msg == 1){
              $(notice_accepted_id).show();
            } else{
              $(notice_rejected_id).show();
            }
         },
         error:function (data, textStatus, jqXHR) {
                  alert("Error Occured");}
    });
  }
</script>

</body>
</html>