<form action="#" style="background-color:white;">
<div class="filters">

  <a href="#" class="heading">BRAND NAME</a>
  <input type="checkbox" name="brandname" value="men" >&nbsp;Ray Ban
  <br>
  <input type="checkbox" name="brandname" value="women">&nbsp;Vincent Chase
  <br>
  <input type="checkbox" name="brandname" value="kids">&nbsp;Vogue
 </div>
  <br>
  
 <div class="filters"> 

  <a href="#" class="heading">FRAME SIZE</a>
  <input type="checkbox" name="framesize" value="small" >&nbsp;Small
  <br>
  <input type="checkbox" name="framesize" value="medium">&nbsp;Medium
  <br>
  <input type="checkbox" name="framesize" value="large">&nbsp;Large
  </div>
  <br>
  
  <div class="filters">

  <a href="#" class="heading">FRAME COLOR</a>
  <input type="checkbox" name="framcolor" value="black" >&nbsp;Black
  <br>
  <input type="checkbox" name="framecolor" value="blue">&nbsp;Blue
  <br>
  <input type="checkbox" name="framecolor" value="yellow">&nbsp;Yellow
  </div>
  <br>
  
  <div class="filters">
	<a href="#" class="heading">DISCOUNTS</a>
  <input type="range" name="disc" min="0" max="50" value="20">
  <br>
  <center><button class="btn btn-info">Filter</button></center>
  <br>
  </div>

  
  
 </form>